/* File:     mpi_vector_add.c
 *
 * Purpose:  Implement parallel vector addition using a block
 *           distribution of the vectors.  This version also
 *           illustrates the use of MPI_Scatter and MPI_Gather.
 *
 * Compile:  mpicc -g -Wall -o mpi_vector_add mpi_vector_add.c
 * Run:      mpiexec -n <comm_sz> ./vector_add
 *
 * Input:    The order of the vectors, n, and the vectors x and y
 * Output:   The sum vector z = x+y
 *
 * Notes:     
 * 1.  The order of the vectors, n, should be evenly divisible
 *     by comm_sz
 * 2.  DEBUG compile flag.    
 * 3.  This program does fairly extensive error checking.  When
 *     an error is detected, a message is printed and the processes
 *     quit.  Errors detected are incorrect values of the vector
 *     order (negative or not evenly divisible by comm_sz), and
 *     malloc failures.
 *
 * IPP:  Section 3.4.6 (pp. 109 and ff.)
 */

#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

void Read_n(int* n_p, int* local_n_p, int my_rank, int comm_sz, MPI_Comm comm);
void Allocate_vectors(double** local_x_pp, double** local_y_pp, double** local_z_pp, int local_n, MPI_Comm comm);
void Read_vector(double local_a[], int local_n, int n, char vec_name[],int my_rank, MPI_Comm comm);
void Print_vector(double local_b[], int local_n, int n, char title[], int my_rank, MPI_Comm comm);
void Parallel_vector_sum(double local_x[], double local_y[], double local_z[], int local_n);


/*-------------------------------------------------------------------*/

int main(void) {
   int		n;		/* the nuumber of components/elelemtns in vector (order of the vector)*/
   int		local_n;	/* the number of elelemnts of a vector assigned per process*/
   int		comm_sz;	/* the number of processes*/
   int		my_rank;	/* rank of this process*/
   double	*local_x;	/* input vector x*/
   double	*local_y;	/* input vector y*/
   double	*local_z; 	/* result of vector addition z = x+y*/
   MPI_Comm 	comm;		/* communicator*/

   MPI_Init(NULL, NULL);
   comm = MPI_COMM_WORLD;
   MPI_Comm_size(comm, &comm_sz);
   MPI_Comm_rank(comm, &my_rank);

   /* Get the order of the vectors n from stdin on proc 0 and broadcast to other processes, and all processes then calculate local_n*/
   Read_n(&n, &local_n, my_rank, comm_sz, comm);

   /* Each process prints its process rank, n, and local_n*/
   printf("Proc %d > n = %d, local_n = %d\n", my_rank, n, local_n);

   /*Allocate storage for x, y, and z*/
   Allocate_vectors(&local_x, &local_y, &local_z, local_n, comm);

   /* Read a vector x from stdin on process 0 and distribute among the processes using a block distribution.*/
   MPI_Barrier(comm);
   Read_vector(local_x, local_n, n, "x", my_rank, comm);

   /* Print vector x to stdout */
   Print_vector(local_x, local_n, n, "x is", my_rank, comm);

   /* Read a vector x from stdin on process 0 and distribute among the processes using a block distribution.*/
   MPI_Barrier(comm);
   Read_vector(local_y, local_n, n, "y", my_rank, comm);

   /* Print vector y to stdout */
   Print_vector(local_y, local_n, n, "y is", my_rank, comm);

   /* Perform parallel vector sum z = x + y */
   Parallel_vector_sum(local_x, local_y, local_z, local_n);

   /* Print vector z to stdout */
   Print_vector(local_z, local_n, n, "The sum is", my_rank, comm);

   /* Free dynamic memory allocated for x ,y, z*/
   free(local_x);
   free(local_y);
   free(local_z);

   MPI_Finalize();

   return 0;
}  /* main */


/*-------------------------------------------------------------------
 * Function:  Read_n
 * Purpose:   Get the order of the vectors from stdin on proc 0 and
 *            broadcast to other processes.
 * In args:   my_rank:    process rank in communicator
 *            comm_sz:    number of processes in communicator
 *            comm:       communicator containing all the processes
 *                        calling Read_n
 * Out args:  n_p:        global value of n
 *            local_n_p:  local value of n = n/comm_sz
 *
 * Errors:    n should be positive and evenly divisible by comm_sz
 */
void Read_n(
      int*      n_p        /* out */, 
      int*      local_n_p  /* out */, 
      int       my_rank    /* in  */, 
      int       comm_sz    /* in  */,
      MPI_Comm  comm       /* in  */) {

    if (my_rank == 0) 
    {
  	/* TODO: Prompt user "What's the order of the vectors?"*/

	/* TODO: Read user input to n (i.e. n_p)*/
   }

   /* TODO: Process 0 broadcast n to all other processes in comm */

   /* TODO: Calculate local_n*/   

}  /* Read_n */

/*-------------------------------------------------------------------
 * Function:  Allocate_vectors
 * Purpose:   Allocate storage for x, y, and z
 * In args:   local_n:  the size of the local vectors
 *            comm:     the communicator containing the calling processes
 * Out args:  local_x_pp, local_y_pp, local_z_pp:  pointers to memory
 *               blocks to be allocated for local vectors
 *
 * Errors:    One or more of the calls to malloc fails
 */
void Allocate_vectors(
      double**   local_x_pp  /* out */, 
      double**   local_y_pp  /* out */,
      double**   local_z_pp  /* out */, 
      int        local_n     /* in  */,
      MPI_Comm   comm        /* in  */) {

   /* TODO: Allocalte space for local_x for local_n doubles*/

   /* TODO: Allocalte space for local_y for local_n doubles*/

   /* TODO: Allocalte space for local_z for local_n doubles*/

}  /* TODO: Allocate_vectors */


/*-------------------------------------------------------------------
 * Function:   Read_vector
 * Purpose:    Read a vector from stdin on process 0 and distribute
 *             among the processes using a block distribution.
 * In args:    local_n:  size of local vectors
 *             n:        size of global vector
 *             vec_name: name of vector being read (e.g., "x")
 *             my_rank:  calling process' rank in comm
 *             comm:     communicator containing calling processes
 * Out arg:    local_a:  local vector read
 *
 * Errors:     if the malloc on process 0 for temporary storage
 *             fails the program terminates
 *
 * Note: 
 *    This function assumes a block distribution and the order
 *   of the vector evenly divisible by comm_sz.
 */
void Read_vector(
      double    local_a[]   /* out */, 
      int       local_n     /* in  */, 
      int       n           /* in  */,
      char      vec_name[]  /* in  */,
      int       my_rank     /* in  */, 
      MPI_Comm  comm        /* in  */) {

   /* Declare a temprary vector pointer a*/
   double* a = NULL;
   int i;

   if (my_rank == 0) 
   {
      /* TODO: Allocate memory for a for n double elements*/

      /* TODO: Prompt the user to enter elelemtns for vector with given vector name " Enter the vector :"*/

      /* TODO: Read user input to populate vector a*/
   } 
   
   /* TODO: Scatter vector among all processes loca_n number of elements per process*/

   if(my_rank==0)
   {
      /* TODO: Free space allocated for temporary vector a*/
   }

}  /* Read_vector */  


/*-------------------------------------------------------------------
 * Function:  Print_vector
 * Purpose:   Print a vector that has a block distribution to stdout
 * In args:   local_b:  local storage for vector to be printed
 *            local_n:  order of local vectors
 *            n:        order of global vector (local_n*comm_sz)
 *            title:    title to precede print out
 *            comm:     communicator containing processes calling
 *                      Print_vector
 *
 * Error:     if process 0 can't allocate temporary storage for
 *            the full vector, the program terminates.
 *
 * Note:
 *    Assumes order of vector is evenly divisible by the number of
 *    processes
 */
void Print_vector(
      double    local_b[]  /* in */, 
      int       local_n    /* in */, 
      int       n          /* in */, 
      char      title[]    /* in */, 
      int       my_rank    /* in */,
      MPI_Comm  comm       /* in */) {

   /* Declare a temprary vector pointer b*/
   double* b = NULL;
   int i;

   if (my_rank == 0) 
   {
      /* TODO: Allocate memory for b for n double elements*/
   }

   /* TODO: Gather vectors of size local_n to b in process 0*/
 
   if (my_rank == 0) 
   {
      /* Print title*/
      printf("%s\n", title);

      /* TODO: Print elements in b*/

      /* TODO: free space allocated for b*/
   } 

}  /* Print_vector */


/*-------------------------------------------------------------------
 * Function:  Parallel_vector_sum
 * Purpose:   Add a vector that's been distributed among the processes
 * In args:   local_x:  local storage of one of the vectors being added
 *            local_y:  local storage for the second vector being added
 *            local_n:  the number of components in local_x, local_y,
 *                      and local_z
 * Out arg:   local_z:  local storage for the sum of the two vectors
 */
void Parallel_vector_sum(
      double  local_x[]  /* in  */, 
      double  local_y[]  /* in  */, 
      double  local_z[]  /* out */, 
      int     local_n    /* in  */) {

   int local_i; //counter

   /* TODO: Perform parallel vector sum local_z = local_x + local_y*/  

}  /* Parallel_vector_sum */


/***************************************output*************************************************
$ mpicc -o mpi_vector_add mpi_vector_add.c
$ mpirun -np 4 mpi_vector_add
What's the order of the vectors?
8
Proc 0 > n = 8, local_n = 2
Proc 2 > n = 8, local_n = 2
Proc 1 > n = 8, local_n = 2
Proc 3 > n = 8, local_n = 2
Enter the vector x
1 2 3 4 5 6 7 8
x is
1.00 2.00 3.00 4.00 5.00 6.00 7.00 8.00 
Enter the vector y
2 3 4 5 6 7 8 9
y is
2.00 3.00 4.00 5.00 6.00 7.00 8.00 9.00 
The sum is
3.00 5.00 7.00 9.00 11.00 13.00 15.00 17.00 
[rdissanayaka@hpc0 200 ~/CS351/mpi]$ 
**********************************************************************************************/
